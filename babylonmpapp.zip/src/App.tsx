import React, { useState, useRef, useEffect } from "react";
import * as Babylon from "@babylonjs/core";
import "./App.css";
import HemisphericLight from "./Components/HemisphericLight";
import CreateCubeObject from "./Components/CreateCubeObject";
import DataParser from "./SarginDrawApi/DataParser";
import TESTDATA from "./testJsonData/test.json";
import SarginDrawEngine, { ICizimChild } from "./SarginDrawApi/SarginDrawEngine";

interface IMousePosition {
  x: number;
  y: number;
}

function App() {
  const [canvasSizes, setCanvasSizes] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });
  const [mousePositions, setMousePositions] = useState<IMousePosition | any>();
  const [transformNodes, setTransformNodes] = useState<Babylon.TransformNode | any>();
  const [cizim, setCizim] = useState<any>();
  const canvasElement = useRef<any>();
  //Yeni Component içerisine gönderileceği zaman state olmalı. Şuan Var kullanmamın sebebi main içerisinden componente göndermediğim için
  const [scene, setScene] = useState<Babylon.Scene>();
  const [loaded, setLoaded] = useState<boolean>(false);

  function setMousePostionsWithEvent(e: EventListenerOrEventListenerObject | any) {
    setMousePositions({ x: e.clientX, y: e.clientY });
  }
  useEffect(() => {
    function resizeWindow() {
      if (scene) {
        setCanvasSizes({ width: window.innerWidth, height: window.innerHeight });
        scene.getEngine().resize();
      }
    }

    window.addEventListener("resize", resizeWindow);

    return () => {
      window.removeEventListener("resize", resizeWindow);
    };
  }, [scene]);

  const createCamera = (scene: Babylon.Scene, canvas: HTMLCanvasElement, paddingSensibilty?: number) => {
    if (scene && canvas) {
      const camera = new Babylon.ArcRotateCamera("Camera", 0, 0, 10, new Babylon.Vector3(0, 0, 0), scene);

      // This targets the camera to scene origin
      camera.setTarget(Babylon.Vector3.Zero());
      camera.setPosition(new Babylon.Vector3(50, -100, -100));

      // This attaches the camera to the canvas
      camera.attachControl(canvas, true);
      //Camera Sensibility
      camera.speed = 100;
      if (mousePositions) {
        camera.panningOriginTarget = new Babylon.Vector3(mousePositions.x, mousePositions.y, camera.position.z);
      }
    }
  };

  useEffect(() => {}, [cizim]);

  useEffect(() => {
    if (!loaded) {
      setLoaded(true);
      const engine = new Babylon.Engine(canvasElement.current, true);
      const scene = new Babylon.Scene(engine);
      createCamera(scene, canvasElement.current);
      setScene(scene);

      if (scene.isReady()) {
        setCizim(DataParser(TESTDATA));
      } else {
        scene.onReadyObservable.addOnce((scene) => renderLoopElements(engine, scene));
      }

      renderLoopElements(engine, scene);
    }
    return () => {
      scene?.dispose();
    };
  }, [canvasElement, mousePositions]);

  function renderLoopElements(engineScene: Babylon.Engine, sceneElement: Babylon.Scene) {
    if (engineScene && sceneElement) {
      engineScene.runRenderLoop(() => {
        sceneElement.render();
      });
    }
  }
  return (
    <div className='App'>
      <canvas width={canvasSizes.width} height={canvasSizes.height} ref={canvasElement}></canvas>
      {scene && (
        <HemisphericLight intensity={5} lightName='FirstLight' position={{ x: 10, y: 10, z: 2 }} scene={scene} />
      )}
      {scene && (
        <CreateCubeObject
          meshWidth={20}
          meshDepth={20}
          meshHeight={0.5}
          meshName='floor'
          scene={scene}
          position={{ x: 0, y: 0, z: 10 }}
          UV={{ col: 1, row: 0.5 }}
        />
      )}
      {scene &&
        cizim &&
        Object.values(cizim).map((collection: any, index: number) => {
          return (
            <SarginDrawEngine
              collection={collection}
              key={index + Math.random()}
              scene={scene}
              collectionName={Object.keys(cizim)[index]}
              nodes={transformNodes}
            />
          );
        })}
    </div>
  );
}

export default App;
